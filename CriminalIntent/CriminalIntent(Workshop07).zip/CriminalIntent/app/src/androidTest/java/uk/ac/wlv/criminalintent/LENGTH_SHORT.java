package uk.ac.wlv.criminalintent;

public class LENGTH_SHORT {
}
